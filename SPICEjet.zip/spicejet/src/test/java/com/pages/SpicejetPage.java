package com.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.FileNotFoundException;
import java.text.ParseException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SpicejetPage  {
	
	WebDriver driver;
	
	String sheetName = "Spicejet";
	
	String fn = "";
	
	ExcelPage ep = new ExcelPage(driver);
	
	@FindBy(xpath = "//*[contains(text(),'Round Trip')]")
	WebElement roundTrip;
	
	@FindBy(id = "ctl00_mainContent_ddl_originStation1_CTXT")
	WebElement from;
	
	@FindBy(id = "ctl00_mainContent_ddl_destinationStation1_CTXT")
	WebElement to;
	
	@FindBy(id = "ctl00_mainContent_view_date1")
	WebElement departdate;
	
	@FindBy(xpath = "(//table[@class='ui-datepicker-calendar']/tbody[1]/tr[3]/td[2]/a[1])[1]")
	WebElement departfromdate;
	
	@FindBy(id = "ctl00_mainContent_view_date2")
	WebElement returndate;
	
	@FindBy(xpath = "(//table[@class='ui-datepicker-calendar']/tbody[1]/tr[3]/td[2]/a[1])[1]")
	WebElement returntodate;
	
	@FindBy(id = "divpaxinfo")
	WebElement Passengers;
	
	@FindBy(xpath = "//select[@id='ctl00_mainContent_ddl_Adult']/child::option[@value='2']")
	WebElement Adult;
	
	@FindBy(id = "ctl00_mainContent_btn_FindFlights")
	WebElement SEARCH;
	
	@FindBy(xpath = "//input[@id='ctl00_mainContent_chk_friendsandfamily']")
	WebElement FamilyandFriends;
	
	@FindBy(xpath = "(//a[@class='special']//span)[1]")
	WebElement flightnumber;
	
	public SpicejetPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	public void selectTrip(String trip) {

		roundTrip.click();

	}
	
	
	public void from(int rowNum, int cellNum) throws FileNotFoundException, InterruptedException {

		String value = ep.getCellValue(sheetName, rowNum, cellNum);

		from.sendKeys(value);
		Thread.sleep(2000);
	}

	public void to(int rowNum, int cellNum) throws FileNotFoundException, InterruptedException {

		String value = ep.getCellValue(sheetName, rowNum, cellNum);
		to.sendKeys(value);
		Thread.sleep(2000);
	}

	
	public void selectDate()  {
		
		  WebDriverWait wait=new WebDriverWait(driver,20);

		
		departdate.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(departfromdate));
		
		departfromdate.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(returndate));

		returndate.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(returntodate));

		returntodate.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(Passengers));
		
		//FamilyandFriends.click();

		Passengers.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(Adult));
		
		Adult.click();
		
		SEARCH.click();
		
		
	}
	
	
	public void flightNumber() {
		
		fn = flightnumber.getText();
		
		System.out.println("Flight Number is :  " +fn);
		
	}
	
	public void clickAnywhere() throws AWTException
	{
		 Actions actions = new Actions(driver);

		  Robot robot = new Robot();

		  robot.mouseMove(50,50);

		  actions.click().build().perform();
	}

}
