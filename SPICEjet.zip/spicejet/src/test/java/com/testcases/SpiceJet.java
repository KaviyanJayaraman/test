package com.testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.pages.SpicejetPage;
import com.utilities.WrapperClass;
import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class SpiceJet extends WrapperClass {
	
	WebDriver driver;
	
   SpicejetPage spicejet;

   @BeforeClass
   @Parameters("browser")
   public void launchBrowser(String browser) throws AWTException, InterruptedException, IOException, ParseException {
   
	   driver= launchBrowser(browser,"https://www.spicejet.com/");
   }
   
   @Test
   public void spiceJettestCase() throws AWTException, InterruptedException, ParseException, IOException {
	   spicejet  = new SpicejetPage(driver);
	   spicejet.selectTrip(null);
	   
	   try {
		spicejet.from(0, 0);
	} catch (FileNotFoundException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	   Thread.sleep(2000);
	   
	   spicejet.to(0, 1);
	   
	   spicejet.selectDate();
	   
	   spicejet.clickAnywhere();
	   takeScreenShot("SCREENSHOT\\SPICEJET1.PNG");
       
	   spicejet.flightNumber();
	   
   }
   
   @AfterClass
   public void closeBrowser() {
         //close current browser
         driver.close();
   }
   
}
