package com.utilities;



import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WrapperClass {
	WebDriver driver;
	static int COUNTER=0;
		public WebDriver launchBrowser(String browser,String URL) throws InterruptedException
		{
			if(browser.contains("Chrome"))   // Check if parameter passed as 'chrome'
			{
				
				//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
				WebDriverManager.chromedriver().setup();
				//creating object in Chromeoptions
				ChromeOptions option=new ChromeOptions();
	            //disable notification in chrome 
				option.addArguments("--disable-notifications");
	            //create chrome instance
				driver=new ChromeDriver(option);
			}
			else if(browser.contains("Firefox"))
			{
				//System.setProperty("webdriver.gecko.driver", ".\\DRIVERS\\geckodriver.exe"); //set path to geckodriver.exe
				WebDriverManager.firefoxdriver().setup();
				FirefoxOptions options = new FirefoxOptions();   //creating object in FirefoxOptions
				options.setProfile(new FirefoxProfile());
				options.addPreference("dom.webnotifications.enabled", false); //disable notification in firefox 
				//create firefox instance
				driver = new FirefoxDriver(options);
				
			}
			
			else if(browser.contains("Microsoft Edge"))
			{
				//System.setProperty("webdriver.gecko.driver", ".\\DRIVERS\\geckodriver.exe"); //set path to geckodriver.exe
				WebDriverManager.edgedriver().setup();
				//options.setProfile(new FirefoxProfile());
				//options.addPreference("dom.webnotifications.enabled", false); //disable notification in firefox */
				//create Microsoft Edge instance
				driver = new EdgeDriver();
				
			}
			
			
			// gets url
			driver.get(URL); 
			//it maximize size of browser
			driver.manage().window().maximize();
			//delete all cookies present on history of page
			driver.manage().deleteAllCookies();
			//set implicit wait in driver
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			// set page load time
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
			//driver.switchTo().frame("paymframe");	

			return driver;
		}
		
		
		public void scrollUp() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-300)");
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("/html/body/div[1]/div[4]/a")).click();
			
		}

		public void takeScreenShot(String path) throws IOException {                       // capturing Screenshot
			
			File screen=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screen,new File(path));

		}
		
		
}

